import { create } from "zustand";
import { useState, useEffect } from "react";
import { headers } from "next/headers";

export interface User {
  user_id: number;
  role: string;
  email: string;
  username: string;
  password: string;
}

interface Student {
  id: number;
  name: string;
  class_id: number;
  parent_id: number;
  address: string;
  user_id: number;
}

interface Parent {
  id: number;
  name: string;
  user_id: number;
  phone_number: string;
}

interface Teacher {
  id: number;
  name: string;
  user_id: number;
}

type userPublicData = {
  actual_user: Partial<User> | null;
  actual_role: Teacher | Parent | Student | null;
  logged: boolean;
  getTestFunction: () => Promise<void>;
  clearLocalStorage: () => void;
  setActualRole: () => Promise<void>;
};

export const useUserPublicData = create<userPublicData>((set) => ({
  actual_user: localStorage.getItem("actual_user")
    ? (JSON.parse(
        localStorage.getItem("actual_user") as string
      ) as Partial<User> | null)
    : null,
  actual_role: localStorage.getItem("actual_role")
    ? (JSON.parse(localStorage.getItem("actual_role") as string) as
        | Teacher
        | Parent
        | Student
        | null)
    : null,
  logged: false,
  getTestFunction: async () => {
    await new Promise((resolve) => setTimeout(resolve, 1000));
    console.log("just an example for an async function");
  },
  clearLocalStorage: () => {
    localStorage.clear();
  },
  setActualRole: async () => {
    if (!localStorage.getItem("actual_user")) {
      return;
    }
    let roleText: string;
    const actualUser = JSON.parse(
      localStorage.getItem("actual_user") as string
    ) as Partial<User> | null;
    const userId = actualUser?.user_id;
    switch (actualUser?.role) {
      case "Student":
        roleText = "students";
        break;
      case "Parent":
        roleText = "parents";
        break;
      case "Teacher":
        roleText = "teachers";
        break;
      default:
        return;
    }
    try {
      const url = `http://localhost:3000/searchbyuserid/${roleText}/${userId}`;
      const options = {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
        },
      };

      const response = await fetch(url, options);

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      const responseData = await response.json();
      console.log(responseData);
    } catch (error) {
      console.error(error);
    }
  },
}));
/* 
const usePersistedUser = () => {
  const [user, setUser] = useState<Partial<User> | null>(null);

  useEffect(() => {
    const storedUser = localStorage.getItem("user");
    if (storedUser) {
      setUser(JSON.parse(storedUser));
    }
  }, []);

  useEffect(() => {
    if (user) {
      localStorage.setItem("user", JSON.stringify(user));
    }
  }, [user]);

  return user;
};

const setActualUser = (fetchedUser: Partial<User>) => {
  useUserPublicData.setState({ actual_user: fetchedUser });
  usePersistedUser(fetchedUser);
};

const logActualUser = () => {
  const user = usePersistedUser();
  console.log("Actual user:");
  console.log(user);
};
 */
