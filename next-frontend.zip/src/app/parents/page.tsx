"use client";

function ParentPage() {
  return <div>Parent page</div>;
}

export default ParentPage;
