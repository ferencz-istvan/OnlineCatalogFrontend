"use client";

import StudentsLayout from "../../layouts/studentsLayout";

function StudentAbsences() {
  return (
    <StudentsLayout>
      <div>Hello</div>
      <div>Student Absences</div>
      <div>Hello</div>
    </StudentsLayout>
  );
}

export default StudentAbsences;
