"use client";

import StudentsLayout from "../../layouts/studentsLayout";

function StudentSubjects() {
  return (
    <StudentsLayout>
      <div>Hello</div>
      <div>Student Subjects</div>
      <div>Hello</div>
    </StudentsLayout>
  );
}

export default StudentSubjects;
