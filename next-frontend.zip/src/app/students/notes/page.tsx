"use client";

import StudentsLayout from "../../layouts/studentsLayout";

function StudentNotes() {
  return (
    <StudentsLayout>
      <div>Hello</div>
      <div>Student Notes</div>
      <div>Hello</div>
    </StudentsLayout>
  );
}

export default StudentNotes;
